# ALL READY-TO-PASTE IMAGE PROMPTS — phase_01_khan_1_vertical_slice

---

# READY-TO-PASTE IMAGE PROMPT — boss_mythic_lion

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `boss_mythic_lion`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_base`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Mythic-creature identity rule:

- The creature must feel like it comes from the **Shahnameh and Iranian mythic world** first, with corruption or hostility added second. Do not drift into generic fantasy-beast design.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Purpose: Khan 1 boss (enemy_lion_boss) — Lion of the First Khan. Gameplay read: Powerful believable lion, tawny fur, darker mane — no armor, no demonic mutation. Output: Base on #00FF00. Canvas/grid: 384×384 base; strips 3072×384. Pivot: bottom-center. Strips: idle, run, claw_attack, pounce_attack, roar, defeat — 8×1 each. Telegraphs must read before impact. ---

## Asset-type contract

Create one isolated full-body sprite unless the asset is explicitly a bust/codex portrait. Keep the full silhouette visible with safe padding. Use bottom-center pivot intent for gameplay sprites. Do not bake a ground plane or cast shadow into the sprite.

## Exact technical export contract

- Exact canvas: 384×384px.
- Grid: 1 columns × 1 rows. Cell size: 384×384px.
- Pivot intent for Godot: bottom-center.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `boss_mythic_lion` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette.

---

# READY-TO-PASTE IMAGE PROMPT — boss_mythic_lion_claw_attack

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `boss_mythic_lion_claw_attack`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Mythic-creature identity rule:

- The creature must feel like it comes from the **Shahnameh and Iranian mythic world** first, with corruption or hostility added second. Do not drift into generic fantasy-beast design.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Animation strip for boss_mythic_lion. Action/state: claw_attack. Preserve the exact approved base design, costume, proportions, material colors, and lighting from boss_mythic_lion in every frame. Clear claw anticipation and impact. Parent design context: Purpose: Khan 1 boss (enemy_lion_boss) — Lion of the First Khan. Gameplay read: Powerful believable lion, tawny fur, darker mane — no armor, no demonic mutation. Output: Base on #00FF00. Canvas/grid: 384×384 base; strips 3072×384. Pivot: bottom-center. Strips: idle, run, claw_attack, pounce_attack, roar, defeat — 8×1 each. Telegraphs must read before impact. ---

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 384×384px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 3072×384px.
- Grid: 8 columns × 1 rows. Cell size: 384×384px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `boss_mythic_lion`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `boss_mythic_lion_claw_attack` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — boss_mythic_lion_defeat

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `boss_mythic_lion_defeat`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Mythic-creature identity rule:

- The creature must feel like it comes from the **Shahnameh and Iranian mythic world** first, with corruption or hostility added second. Do not drift into generic fantasy-beast design.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Animation strip for boss_mythic_lion. Action/state: defeat. Preserve the exact approved base design, costume, proportions, material colors, and lighting from boss_mythic_lion in every frame. Non-gory defeat, no demonic dissolve. Parent design context: Purpose: Khan 1 boss (enemy_lion_boss) — Lion of the First Khan. Gameplay read: Powerful believable lion, tawny fur, darker mane — no armor, no demonic mutation. Output: Base on #00FF00. Canvas/grid: 384×384 base; strips 3072×384. Pivot: bottom-center. Strips: idle, run, claw_attack, pounce_attack, roar, defeat — 8×1 each. Telegraphs must read before impact. ---

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 384×384px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 3072×384px.
- Grid: 8 columns × 1 rows. Cell size: 384×384px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `boss_mythic_lion`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `boss_mythic_lion_defeat` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — boss_mythic_lion_idle

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `boss_mythic_lion_idle`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Mythic-creature identity rule:

- The creature must feel like it comes from the **Shahnameh and Iranian mythic world** first, with corruption or hostility added second. Do not drift into generic fantasy-beast design.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Animation strip for boss_mythic_lion. Action/state: idle. Preserve the exact approved base design, costume, proportions, material colors, and lighting from boss_mythic_lion in every frame. Powerful believable lion idle. Parent design context: Purpose: Khan 1 boss (enemy_lion_boss) — Lion of the First Khan. Gameplay read: Powerful believable lion, tawny fur, darker mane — no armor, no demonic mutation. Output: Base on #00FF00. Canvas/grid: 384×384 base; strips 3072×384. Pivot: bottom-center. Strips: idle, run, claw_attack, pounce_attack, roar, defeat — 8×1 each. Telegraphs must read before impact. ---

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 384×384px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 3072×384px.
- Grid: 8 columns × 1 rows. Cell size: 384×384px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `boss_mythic_lion`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `boss_mythic_lion_idle` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — boss_mythic_lion_pounce_attack

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `boss_mythic_lion_pounce_attack`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Mythic-creature identity rule:

- The creature must feel like it comes from the **Shahnameh and Iranian mythic world** first, with corruption or hostility added second. Do not drift into generic fantasy-beast design.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Animation strip for boss_mythic_lion. Action/state: pounce_attack. Preserve the exact approved base design, costume, proportions, material colors, and lighting from boss_mythic_lion in every frame. Coil, leap, impact, recovery. Parent design context: Purpose: Khan 1 boss (enemy_lion_boss) — Lion of the First Khan. Gameplay read: Powerful believable lion, tawny fur, darker mane — no armor, no demonic mutation. Output: Base on #00FF00. Canvas/grid: 384×384 base; strips 3072×384. Pivot: bottom-center. Strips: idle, run, claw_attack, pounce_attack, roar, defeat — 8×1 each. Telegraphs must read before impact. ---

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 384×384px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 3072×384px.
- Grid: 8 columns × 1 rows. Cell size: 384×384px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `boss_mythic_lion`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `boss_mythic_lion_pounce_attack` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — boss_mythic_lion_roar

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `boss_mythic_lion_roar`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Mythic-creature identity rule:

- The creature must feel like it comes from the **Shahnameh and Iranian mythic world** first, with corruption or hostility added second. Do not drift into generic fantasy-beast design.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Animation strip for boss_mythic_lion. Action/state: roar. Preserve the exact approved base design, costume, proportions, material colors, and lighting from boss_mythic_lion in every frame. Roar telegraph and mane movement. Parent design context: Purpose: Khan 1 boss (enemy_lion_boss) — Lion of the First Khan. Gameplay read: Powerful believable lion, tawny fur, darker mane — no armor, no demonic mutation. Output: Base on #00FF00. Canvas/grid: 384×384 base; strips 3072×384. Pivot: bottom-center. Strips: idle, run, claw_attack, pounce_attack, roar, defeat — 8×1 each. Telegraphs must read before impact. ---

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 384×384px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 3072×384px.
- Grid: 8 columns × 1 rows. Cell size: 384×384px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `boss_mythic_lion`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `boss_mythic_lion_roar` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — boss_mythic_lion_run

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `boss_mythic_lion_run`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Mythic-creature identity rule:

- The creature must feel like it comes from the **Shahnameh and Iranian mythic world** first, with corruption or hostility added second. Do not drift into generic fantasy-beast design.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Animation strip for boss_mythic_lion. Action/state: run. Preserve the exact approved base design, costume, proportions, material colors, and lighting from boss_mythic_lion in every frame. Heavy feline run. Parent design context: Purpose: Khan 1 boss (enemy_lion_boss) — Lion of the First Khan. Gameplay read: Powerful believable lion, tawny fur, darker mane — no armor, no demonic mutation. Output: Base on #00FF00. Canvas/grid: 384×384 base; strips 3072×384. Pivot: bottom-center. Strips: idle, run, claw_attack, pounce_attack, roar, defeat — 8×1 each. Telegraphs must read before impact. ---

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 384×384px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 3072×384px.
- Grid: 8 columns × 1 rows. Cell size: 384×384px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `boss_mythic_lion`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `boss_mythic_lion_run` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — companion_rakhsh

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `companion_rakhsh`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_base`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Rakhsh-specific identity markers — mandatory:

- Rakhsh must read as a **legendary Shahnameh warhorse**, not an ordinary horse.
- Emphasize heroic intelligence, powerful chest and legs, noble expression, Persian-decorated tack, and epic partner-of-Rostam status.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Purpose: Narrative companion; warning support (not playable). Gameplay read: Heroic stallion — warm reddish coat, darker mane/tail, restrained saddle, bronze and teal tack. Output: Base sprite on #00FF00. Canvas/grid: 256×256. Pivot: bottom-center. Strips (separate requests): companion_rakhsh_idle, companion_rakhsh_run, companion_rakhsh_warning_stomp — 8×1 @ 256² each. ---

## Asset-type contract

Create one isolated full-body sprite unless the asset is explicitly a bust/codex portrait. Keep the full silhouette visible with safe padding. Use bottom-center pivot intent for gameplay sprites. Do not bake a ground plane or cast shadow into the sprite.

## Exact technical export contract

- Exact canvas: 256×256px.
- Grid: 1 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `companion_rakhsh` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette.

---

# READY-TO-PASTE IMAGE PROMPT — companion_rakhsh_idle

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `companion_rakhsh_idle`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Rakhsh-specific identity markers — mandatory:

- Rakhsh must read as a **legendary Shahnameh warhorse**, not an ordinary horse.
- Emphasize heroic intelligence, powerful chest and legs, noble expression, Persian-decorated tack, and epic partner-of-Rostam status.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Animation strip for companion_rakhsh. Action/state: idle. Preserve the exact approved base design, costume, proportions, material colors, and lighting from companion_rakhsh in every frame. Subtle breathing and mane settle. Parent design context: Purpose: Narrative companion; warning support (not playable). Gameplay read: Heroic stallion — warm reddish coat, darker mane/tail, restrained saddle, bronze and teal tack. Output: Base sprite on #00FF00. Canvas/grid: 256×256. Pivot: bottom-center. Strips (separate requests): companion_rakhsh_idle, companion_rakhsh_run, companion_rakhsh_warning_stomp — 8×1 @ 256² each. ---

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `companion_rakhsh`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `companion_rakhsh_idle` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — companion_rakhsh_run

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `companion_rakhsh_run`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Rakhsh-specific identity markers — mandatory:

- Rakhsh must read as a **legendary Shahnameh warhorse**, not an ordinary horse.
- Emphasize heroic intelligence, powerful chest and legs, noble expression, Persian-decorated tack, and epic partner-of-Rostam status.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Animation strip for companion_rakhsh. Action/state: run. Preserve the exact approved base design, costume, proportions, material colors, and lighting from companion_rakhsh in every frame. Controlled gallop loop, readable hoof cycle. Parent design context: Purpose: Narrative companion; warning support (not playable). Gameplay read: Heroic stallion — warm reddish coat, darker mane/tail, restrained saddle, bronze and teal tack. Output: Base sprite on #00FF00. Canvas/grid: 256×256. Pivot: bottom-center. Strips (separate requests): companion_rakhsh_idle, companion_rakhsh_run, companion_rakhsh_warning_stomp — 8×1 @ 256² each. ---

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `companion_rakhsh`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `companion_rakhsh_run` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — companion_rakhsh_warning_stomp

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `companion_rakhsh_warning_stomp`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Rakhsh-specific identity markers — mandatory:

- Rakhsh must read as a **legendary Shahnameh warhorse**, not an ordinary horse.
- Emphasize heroic intelligence, powerful chest and legs, noble expression, Persian-decorated tack, and epic partner-of-Rostam status.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Animation strip for companion_rakhsh. Action/state: warning_stomp. Preserve the exact approved base design, costume, proportions, material colors, and lighting from companion_rakhsh in every frame. Warning stomp with anticipation and dust accent. Parent design context: Purpose: Narrative companion; warning support (not playable). Gameplay read: Heroic stallion — warm reddish coat, darker mane/tail, restrained saddle, bronze and teal tack. Output: Base sprite on #00FF00. Canvas/grid: 256×256. Pivot: bottom-center. Strips (separate requests): companion_rakhsh_idle, companion_rakhsh_run, companion_rakhsh_warning_stomp — 8×1 @ 256² each. ---

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `companion_rakhsh`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `companion_rakhsh_warning_stomp` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — enemy_corrupted_boar

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `enemy_corrupted_boar`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_base`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Mythic-creature identity rule:

- The creature must feel like it comes from the **Shahnameh and Iranian mythic world** first, with corruption or hostility added second. Do not drift into generic fantasy-beast design.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Purpose: Armored brute (enemy_boar). Gameplay read: Broad low silhouette, dark bristles, short tusks, restrained corruption. Output: Base on #00FF00. Canvas/grid: 192×192 base; strips 1536×192. Pivot: bottom-center. Strips: walk, charge, defeat — 8×1 each. ---

## Asset-type contract

Create one isolated full-body sprite unless the asset is explicitly a bust/codex portrait. Keep the full silhouette visible with safe padding. Use bottom-center pivot intent for gameplay sprites. Do not bake a ground plane or cast shadow into the sprite.

## Exact technical export contract

- Exact canvas: 192×192px.
- Grid: 1 columns × 1 rows. Cell size: 192×192px.
- Pivot intent for Godot: bottom-center.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `enemy_corrupted_boar` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette.

---

# READY-TO-PASTE IMAGE PROMPT — enemy_corrupted_boar_charge

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `enemy_corrupted_boar_charge`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Mythic-creature identity rule:

- The creature must feel like it comes from the **Shahnameh and Iranian mythic world** first, with corruption or hostility added second. Do not drift into generic fantasy-beast design.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Animation strip for enemy_corrupted_boar. Action/state: charge. Preserve the exact approved base design, costume, proportions, material colors, and lighting from enemy_corrupted_boar in every frame. Readable lowered-head charge telegraph. Parent design context: Purpose: Armored brute (enemy_boar). Gameplay read: Broad low silhouette, dark bristles, short tusks, restrained corruption. Output: Base on #00FF00. Canvas/grid: 192×192 base; strips 1536×192. Pivot: bottom-center. Strips: walk, charge, defeat — 8×1 each. ---

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 192×192px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 1536×192px.
- Grid: 8 columns × 1 rows. Cell size: 192×192px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `enemy_corrupted_boar`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `enemy_corrupted_boar_charge` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — enemy_corrupted_boar_defeat

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `enemy_corrupted_boar_defeat`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Mythic-creature identity rule:

- The creature must feel like it comes from the **Shahnameh and Iranian mythic world** first, with corruption or hostility added second. Do not drift into generic fantasy-beast design.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Animation strip for enemy_corrupted_boar. Action/state: defeat. Preserve the exact approved base design, costume, proportions, material colors, and lighting from enemy_corrupted_boar in every frame. Non-gory collapse and corruption fade. Parent design context: Purpose: Armored brute (enemy_boar). Gameplay read: Broad low silhouette, dark bristles, short tusks, restrained corruption. Output: Base on #00FF00. Canvas/grid: 192×192 base; strips 1536×192. Pivot: bottom-center. Strips: walk, charge, defeat — 8×1 each. ---

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 192×192px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 1536×192px.
- Grid: 8 columns × 1 rows. Cell size: 192×192px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `enemy_corrupted_boar`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `enemy_corrupted_boar_defeat` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — enemy_corrupted_boar_walk

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `enemy_corrupted_boar_walk`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Mythic-creature identity rule:

- The creature must feel like it comes from the **Shahnameh and Iranian mythic world** first, with corruption or hostility added second. Do not drift into generic fantasy-beast design.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Animation strip for enemy_corrupted_boar. Action/state: walk. Preserve the exact approved base design, costume, proportions, material colors, and lighting from enemy_corrupted_boar in every frame. Heavy armored walk. Parent design context: Purpose: Armored brute (enemy_boar). Gameplay read: Broad low silhouette, dark bristles, short tusks, restrained corruption. Output: Base on #00FF00. Canvas/grid: 192×192 base; strips 1536×192. Pivot: bottom-center. Strips: walk, charge, defeat — 8×1 each. ---

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 192×192px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 1536×192px.
- Grid: 8 columns × 1 rows. Cell size: 192×192px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `enemy_corrupted_boar`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `enemy_corrupted_boar_walk` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — enemy_corrupted_jackal

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `enemy_corrupted_jackal`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_base`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Mythic-creature identity rule:

- The creature must feel like it comes from the **Shahnameh and Iranian mythic world** first, with corruption or hostility added second. Do not drift into generic fantasy-beast design.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Purpose: Fast grunt (enemy_jackal). Gameplay read: Lean jackal, dusty-brown fur, subtle charcoal corruption veins — no exaggerated mutation. Output: Base on #00FF00. Canvas/grid: 192×192 base; strips 1536×192. Pivot: bottom-center. Strips: run, bite_attack, defeat — 8×1 each @ 192². ---

## Asset-type contract

Create one isolated full-body sprite unless the asset is explicitly a bust/codex portrait. Keep the full silhouette visible with safe padding. Use bottom-center pivot intent for gameplay sprites. Do not bake a ground plane or cast shadow into the sprite.

## Exact technical export contract

- Exact canvas: 192×192px.
- Grid: 1 columns × 1 rows. Cell size: 192×192px.
- Pivot intent for Godot: bottom-center.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `enemy_corrupted_jackal` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette.

---

# READY-TO-PASTE IMAGE PROMPT — enemy_corrupted_jackal_bite_attack

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `enemy_corrupted_jackal_bite_attack`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Mythic-creature identity rule:

- The creature must feel like it comes from the **Shahnameh and Iranian mythic world** first, with corruption or hostility added second. Do not drift into generic fantasy-beast design.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Animation strip for enemy_corrupted_jackal. Action/state: bite_attack. Preserve the exact approved base design, costume, proportions, material colors, and lighting from enemy_corrupted_jackal in every frame. Bite telegraph with anticipation, snap impact, recovery. Parent design context: Purpose: Fast grunt (enemy_jackal). Gameplay read: Lean jackal, dusty-brown fur, subtle charcoal corruption veins — no exaggerated mutation. Output: Base on #00FF00. Canvas/grid: 192×192 base; strips 1536×192. Pivot: bottom-center. Strips: run, bite_attack, defeat — 8×1 each @ 192². ---

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 192×192px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 1536×192px.
- Grid: 8 columns × 1 rows. Cell size: 192×192px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `enemy_corrupted_jackal`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `enemy_corrupted_jackal_bite_attack` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — enemy_corrupted_jackal_defeat

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `enemy_corrupted_jackal_defeat`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Mythic-creature identity rule:

- The creature must feel like it comes from the **Shahnameh and Iranian mythic world** first, with corruption or hostility added second. Do not drift into generic fantasy-beast design.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Animation strip for enemy_corrupted_jackal. Action/state: defeat. Preserve the exact approved base design, costume, proportions, material colors, and lighting from enemy_corrupted_jackal in every frame. Non-gory corruption dissolve. Parent design context: Purpose: Fast grunt (enemy_jackal). Gameplay read: Lean jackal, dusty-brown fur, subtle charcoal corruption veins — no exaggerated mutation. Output: Base on #00FF00. Canvas/grid: 192×192 base; strips 1536×192. Pivot: bottom-center. Strips: run, bite_attack, defeat — 8×1 each @ 192². ---

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 192×192px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 1536×192px.
- Grid: 8 columns × 1 rows. Cell size: 192×192px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `enemy_corrupted_jackal`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `enemy_corrupted_jackal_defeat` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — enemy_corrupted_jackal_run

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `enemy_corrupted_jackal_run`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Mythic-creature identity rule:

- The creature must feel like it comes from the **Shahnameh and Iranian mythic world** first, with corruption or hostility added second. Do not drift into generic fantasy-beast design.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Animation strip for enemy_corrupted_jackal. Action/state: run. Preserve the exact approved base design, costume, proportions, material colors, and lighting from enemy_corrupted_jackal in every frame. Fast lean run loop. Parent design context: Purpose: Fast grunt (enemy_jackal). Gameplay read: Lean jackal, dusty-brown fur, subtle charcoal corruption veins — no exaggerated mutation. Output: Base on #00FF00. Canvas/grid: 192×192 base; strips 1536×192. Pivot: bottom-center. Strips: run, bite_attack, defeat — 8×1 each @ 192². ---

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 192×192px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 1536×192px.
- Grid: 8 columns × 1 rows. Cell size: 192×192px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `enemy_corrupted_jackal`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `enemy_corrupted_jackal_run` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — enemy_corruptor

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `enemy_corruptor`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_base`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Mythic-creature identity rule:

- The creature must feel like it comes from the **Shahnameh and Iranian mythic world** first, with corruption or hostility added second. Do not drift into generic fantasy-beast design.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Purpose: Region pressure; grants Sacred Fire on kill (enemy_corruptor). Gameplay read: Hunched figure carrying dark jar or serpent motif; corruptor readable at ~48px height. Output: Base on #00FF00. Canvas/grid: 192×192 base. Pivot: bottom-center. Strips: run, corrupt, defeat — 8×1 each. ---

## Asset-type contract

Create one isolated full-body sprite unless the asset is explicitly a bust/codex portrait. Keep the full silhouette visible with safe padding. Use bottom-center pivot intent for gameplay sprites. Do not bake a ground plane or cast shadow into the sprite.

## Exact technical export contract

- Exact canvas: 192×192px.
- Grid: 1 columns × 1 rows. Cell size: 192×192px.
- Pivot intent for Godot: bottom-center.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `enemy_corruptor` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette.

---

# READY-TO-PASTE IMAGE PROMPT — enemy_corruptor_corrupt

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `enemy_corruptor_corrupt`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Mythic-creature identity rule:

- The creature must feel like it comes from the **Shahnameh and Iranian mythic world** first, with corruption or hostility added second. Do not drift into generic fantasy-beast design.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Animation strip for enemy_corruptor. Action/state: corrupt. Preserve the exact approved base design, costume, proportions, material colors, and lighting from enemy_corruptor in every frame. Dark jar or serpent pulse corrupting a region. Parent design context: Purpose: Region pressure; grants Sacred Fire on kill (enemy_corruptor). Gameplay read: Hunched figure carrying dark jar or serpent motif; corruptor readable at ~48px height. Output: Base on #00FF00. Canvas/grid: 192×192 base. Pivot: bottom-center. Strips: run, corrupt, defeat — 8×1 each. ---

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 192×192px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 1536×192px.
- Grid: 8 columns × 1 rows. Cell size: 192×192px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `enemy_corruptor`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `enemy_corruptor_corrupt` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — enemy_corruptor_defeat

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `enemy_corruptor_defeat`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Mythic-creature identity rule:

- The creature must feel like it comes from the **Shahnameh and Iranian mythic world** first, with corruption or hostility added second. Do not drift into generic fantasy-beast design.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Animation strip for enemy_corruptor. Action/state: defeat. Preserve the exact approved base design, costume, proportions, material colors, and lighting from enemy_corruptor in every frame. Non-gory dissolve with Sacred Fire release hint. Parent design context: Purpose: Region pressure; grants Sacred Fire on kill (enemy_corruptor). Gameplay read: Hunched figure carrying dark jar or serpent motif; corruptor readable at ~48px height. Output: Base on #00FF00. Canvas/grid: 192×192 base. Pivot: bottom-center. Strips: run, corrupt, defeat — 8×1 each. ---

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 192×192px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 1536×192px.
- Grid: 8 columns × 1 rows. Cell size: 192×192px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `enemy_corruptor`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `enemy_corruptor_defeat` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — enemy_corruptor_run

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `enemy_corruptor_run`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Mythic-creature identity rule:

- The creature must feel like it comes from the **Shahnameh and Iranian mythic world** first, with corruption or hostility added second. Do not drift into generic fantasy-beast design.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Animation strip for enemy_corruptor. Action/state: run. Preserve the exact approved base design, costume, proportions, material colors, and lighting from enemy_corruptor in every frame. Hunched run while dark jar remains readable. Parent design context: Purpose: Region pressure; grants Sacred Fire on kill (enemy_corruptor). Gameplay read: Hunched figure carrying dark jar or serpent motif; corruptor readable at ~48px height. Output: Base on #00FF00. Canvas/grid: 192×192 base. Pivot: bottom-center. Strips: run, corrupt, defeat — 8×1 each. ---

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 192×192px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 1536×192px.
- Grid: 8 columns × 1 rows. Cell size: 192×192px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `enemy_corruptor`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `enemy_corruptor_run` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — props_shared_vertical_slice

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `props_shared_vertical_slice`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `prop_atlas`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Purpose: 16-prop atlas for Khan 1. Props (one atlas request or one prop per request): 1. Sacred Fire brazier (lit) 2. extinguished brazier 3. corrupted brazier 4. woodland rock 5. reeds 6. woodland shrub 7. small tree 8. dead tree 9. hero-rest carpet 10. broken shield 11. rope coil 12. lasso coil 13. sword in ground 14. fallen banner (no text) 15. gate repair material 16. Sacred stone marker Output: Prop atlas on #00FF00 or isolated props. Pivot: center (brazier bottom-center). ---

## Asset-type contract

Create a prop atlas with exactly 4×4 equal cells, one isolated prop per cell, consistent spacing, and no overlap.

## Exact technical export contract

- Exact canvas: 1024×1024px.
- Grid: 4 columns × 4 rows. Cell size: 256×256px.
- Pivot intent for Godot: center.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/props/`. Use stable asset ID `props_shared_vertical_slice` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — tower_archer

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_archer`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_base`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Timber watchtower, bow racks, quivers, teal canopy; fast damage-per-second archer role; clear arrow release origin.

## Asset-type contract

Create one isolated tower state. Keep a fixed bottom-center footprint and a clear projectile or effect origin. Do not bake terrain underneath the tower.

## Exact technical export contract

- Exact canvas: 256×256px.
- Grid: 1 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_archer` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — tower_archer_attack

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_archer_attack`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_archer. Action/state: attack. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_archer in every frame. Clear anticipation, release or projectile-origin moment, and recovery. The projectile origin must remain visually obvious. Parent design context: Timber watchtower, bow racks, quivers, teal canopy; fast damage-per-second archer role; clear arrow release origin.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_archer`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_archer_attack` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_archer_construction

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_archer_construction`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_archer. Action/state: construction. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_archer in every frame. Readable build-up from foundation to complete tower while preserving the same 256×256 footprint. Parent design context: Timber watchtower, bow racks, quivers, teal canopy; fast damage-per-second archer role; clear arrow release origin.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_archer`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_archer_construction` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_archer_corruption_warning

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_archer_corruption_warning`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_archer. Action/state: corruption_warning. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_archer in every frame. Threat warning before hijack: restrained shadow-violet veins and hostile warning motifs, but tower remains recognizable. Parent design context: Timber watchtower, bow racks, quivers, teal canopy; fast damage-per-second archer role; clear arrow release origin.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_archer`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_archer_corruption_warning` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_archer_hijacked

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_archer_hijacked`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_archer. Action/state: hijacked. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_archer in every frame. Hostile corrupted state: silhouette alteration plus violet/charcoal hostile motifs, not a simple color tint. Preserve footprint. Parent design context: Timber watchtower, bow racks, quivers, teal canopy; fast damage-per-second archer role; clear arrow release origin.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_archer`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_archer_hijacked` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_archer_idle

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_archer_idle`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_archer. Action/state: idle. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_archer in every frame. Subtle loop: restrained cloth, flame, mechanical, or ambient movement only. Fixed footprint; no sliding. Parent design context: Timber watchtower, bow racks, quivers, teal canopy; fast damage-per-second archer role; clear arrow release origin.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_archer`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_archer_idle` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_archer_purification

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_archer_purification`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_archer. Action/state: purification. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_archer in every frame. Sacred Fire recovery loop: gold-orange cleansing pulse removing shadow-violet corruption. Preserve footprint. Parent design context: Timber watchtower, bow racks, quivers, teal canopy; fast damage-per-second archer role; clear arrow release origin.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_archer`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_archer_purification` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_control

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_control`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_base`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Qanat and wind-tower silhouette, cloth streamers, turquoise channel, bronze pipes; slow/control role.

## Asset-type contract

Create one isolated tower state. Keep a fixed bottom-center footprint and a clear projectile or effect origin. Do not bake terrain underneath the tower.

## Exact technical export contract

- Exact canvas: 256×256px.
- Grid: 1 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_control` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — tower_control_attack

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_control_attack`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_control. Action/state: attack. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_control in every frame. Clear anticipation, release or projectile-origin moment, and recovery. The projectile origin must remain visually obvious. Parent design context: Qanat and wind-tower silhouette, cloth streamers, turquoise channel, bronze pipes; slow/control role.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_control`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_control_attack` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_control_construction

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_control_construction`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_control. Action/state: construction. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_control in every frame. Readable build-up from foundation to complete tower while preserving the same 256×256 footprint. Parent design context: Qanat and wind-tower silhouette, cloth streamers, turquoise channel, bronze pipes; slow/control role.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_control`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_control_construction` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_control_corruption_warning

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_control_corruption_warning`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_control. Action/state: corruption_warning. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_control in every frame. Threat warning before hijack: restrained shadow-violet veins and hostile warning motifs, but tower remains recognizable. Parent design context: Qanat and wind-tower silhouette, cloth streamers, turquoise channel, bronze pipes; slow/control role.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_control`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_control_corruption_warning` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_control_hijacked

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_control_hijacked`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_control. Action/state: hijacked. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_control in every frame. Hostile corrupted state: silhouette alteration plus violet/charcoal hostile motifs, not a simple color tint. Preserve footprint. Parent design context: Qanat and wind-tower silhouette, cloth streamers, turquoise channel, bronze pipes; slow/control role.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_control`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_control_hijacked` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_control_idle

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_control_idle`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_control. Action/state: idle. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_control in every frame. Subtle loop: restrained cloth, flame, mechanical, or ambient movement only. Fixed footprint; no sliding. Parent design context: Qanat and wind-tower silhouette, cloth streamers, turquoise channel, bronze pipes; slow/control role.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_control`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_control_idle` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_control_purification

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_control_purification`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_control. Action/state: purification. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_control in every frame. Sacred Fire recovery loop: gold-orange cleansing pulse removing shadow-violet corruption. Preserve footprint. Parent design context: Qanat and wind-tower silhouette, cloth streamers, turquoise channel, bronze pipes; slow/control role.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_control`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_control_purification` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_heavy

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_heavy`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_base`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Thick masonry, bronze reinforcement, restrained ox-head motif, heavy launcher; siege role with broad silhouette.

## Asset-type contract

Create one isolated tower state. Keep a fixed bottom-center footprint and a clear projectile or effect origin. Do not bake terrain underneath the tower.

## Exact technical export contract

- Exact canvas: 256×256px.
- Grid: 1 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_heavy` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — tower_heavy_attack

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_heavy_attack`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_heavy. Action/state: attack. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_heavy in every frame. Clear anticipation, release or projectile-origin moment, and recovery. The projectile origin must remain visually obvious. Parent design context: Thick masonry, bronze reinforcement, restrained ox-head motif, heavy launcher; siege role with broad silhouette.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_heavy`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_heavy_attack` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_heavy_construction

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_heavy_construction`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_heavy. Action/state: construction. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_heavy in every frame. Readable build-up from foundation to complete tower while preserving the same 256×256 footprint. Parent design context: Thick masonry, bronze reinforcement, restrained ox-head motif, heavy launcher; siege role with broad silhouette.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_heavy`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_heavy_construction` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_heavy_corruption_warning

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_heavy_corruption_warning`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_heavy. Action/state: corruption_warning. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_heavy in every frame. Threat warning before hijack: restrained shadow-violet veins and hostile warning motifs, but tower remains recognizable. Parent design context: Thick masonry, bronze reinforcement, restrained ox-head motif, heavy launcher; siege role with broad silhouette.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_heavy`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_heavy_corruption_warning` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_heavy_hijacked

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_heavy_hijacked`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_heavy. Action/state: hijacked. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_heavy in every frame. Hostile corrupted state: silhouette alteration plus violet/charcoal hostile motifs, not a simple color tint. Preserve footprint. Parent design context: Thick masonry, bronze reinforcement, restrained ox-head motif, heavy launcher; siege role with broad silhouette.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_heavy`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_heavy_hijacked` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_heavy_idle

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_heavy_idle`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_heavy. Action/state: idle. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_heavy in every frame. Subtle loop: restrained cloth, flame, mechanical, or ambient movement only. Fixed footprint; no sliding. Parent design context: Thick masonry, bronze reinforcement, restrained ox-head motif, heavy launcher; siege role with broad silhouette.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_heavy`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_heavy_idle` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_heavy_purification

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_heavy_purification`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_heavy. Action/state: purification. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_heavy in every frame. Sacred Fire recovery loop: gold-orange cleansing pulse removing shadow-violet corruption. Preserve footprint. Parent design context: Thick masonry, bronze reinforcement, restrained ox-head motif, heavy launcher; siege role with broad silhouette.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_heavy`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_heavy_purification` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_sacred_fire

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_sacred_fire`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_base`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Stone and brick brazier tower, flame bowl, copper ornament; burn and cleanse role; Sacred Fire unmistakable at zoom-out.

## Asset-type contract

Create one isolated tower state. Keep a fixed bottom-center footprint and a clear projectile or effect origin. Do not bake terrain underneath the tower.

## Exact technical export contract

- Exact canvas: 256×256px.
- Grid: 1 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_sacred_fire` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — tower_sacred_fire_attack

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_sacred_fire_attack`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_sacred_fire. Action/state: attack. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_sacred_fire in every frame. Clear anticipation, release or projectile-origin moment, and recovery. The projectile origin must remain visually obvious. Parent design context: Stone and brick brazier tower, flame bowl, copper ornament; burn and cleanse role; Sacred Fire unmistakable at zoom-out.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_sacred_fire`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_sacred_fire_attack` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_sacred_fire_construction

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_sacred_fire_construction`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_sacred_fire. Action/state: construction. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_sacred_fire in every frame. Readable build-up from foundation to complete tower while preserving the same 256×256 footprint. Parent design context: Stone and brick brazier tower, flame bowl, copper ornament; burn and cleanse role; Sacred Fire unmistakable at zoom-out.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_sacred_fire`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_sacred_fire_construction` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_sacred_fire_corruption_warning

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_sacred_fire_corruption_warning`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_sacred_fire. Action/state: corruption_warning. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_sacred_fire in every frame. Threat warning before hijack: restrained shadow-violet veins and hostile warning motifs, but tower remains recognizable. Parent design context: Stone and brick brazier tower, flame bowl, copper ornament; burn and cleanse role; Sacred Fire unmistakable at zoom-out.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_sacred_fire`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_sacred_fire_corruption_warning` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_sacred_fire_hijacked

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_sacred_fire_hijacked`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_sacred_fire. Action/state: hijacked. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_sacred_fire in every frame. Hostile corrupted state: silhouette alteration plus violet/charcoal hostile motifs, not a simple color tint. Preserve footprint. Parent design context: Stone and brick brazier tower, flame bowl, copper ornament; burn and cleanse role; Sacred Fire unmistakable at zoom-out.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_sacred_fire`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_sacred_fire_hijacked` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_sacred_fire_idle

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_sacred_fire_idle`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_sacred_fire. Action/state: idle. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_sacred_fire in every frame. Subtle loop: restrained cloth, flame, mechanical, or ambient movement only. Fixed footprint; no sliding. Parent design context: Stone and brick brazier tower, flame bowl, copper ornament; burn and cleanse role; Sacred Fire unmistakable at zoom-out.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_sacred_fire`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_sacred_fire_idle` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — tower_sacred_fire_purification

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tower_sacred_fire_purification`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `tower_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

Animation strip for tower_sacred_fire. Action/state: purification. Preserve the exact approved base design, costume, proportions, material colors, and lighting from tower_sacred_fire in every frame. Sacred Fire recovery loop: gold-orange cleansing pulse removing shadow-violet corruption. Preserve footprint. Parent design context: Stone and brick brazier tower, flame bowl, copper ornament; burn and cleanse role; Sacred Fire unmistakable at zoom-out.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `tower_sacred_fire`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/towers/`. Use stable asset ID `tower_sacred_fire_purification` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — vfx_arrow_impact

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `vfx_arrow_impact`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `vfx_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Small hit burst, dust, restrained bronze spark.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: center.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/vfx/`. Use stable asset ID `vfx_arrow_impact` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — vfx_arrow_release

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `vfx_arrow_release`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `vfx_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Bow release flash, ivory motion line, restrained bronze spark.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: center.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/vfx/`. Use stable asset ID `vfx_arrow_release` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — vfx_region_corruption_stage_01

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `vfx_region_corruption_stage_01`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `vfx_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Subtle ground veins: charcoal, muted shadow-violet, cold blue.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: center.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/vfx/`. Use stable asset ID `vfx_region_corruption_stage_01` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — vfx_sacred_fire_cleanse

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `vfx_sacred_fire_cleanse`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `vfx_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Radial gold, orange, and ivory purification burning away dark tendrils.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: center.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/vfx/`. Use stable asset ID `vfx_sacred_fire_cleanse` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — vfx_sacred_tether_beam

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `vfx_sacred_tether_beam`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `beam_texture`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Purpose: Hero ↔ tower tether (code deferred). Gameplay read: Gold-white core line, soft trail; distinct from corruption purple. Output: Horizontal beam texture or 8×1 pulse strip @ 256² on #00FF00. Pivot: center. ---

## Asset-type contract

Create one isolated horizontal beam or chain texture with clean ends and no scenery.

## Exact technical export contract

- Exact canvas: 256×256px.
- Grid: 1 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: center.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/vfx/`. Use stable asset ID `vfx_sacred_tether_beam` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — vfx_tower_hijack_start

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `vfx_tower_hijack_start`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `vfx_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Dark ribbons coil upward around one tower footprint.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: center.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/vfx/`. Use stable asset ID `vfx_tower_hijack_start` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — build_spot_base_tile

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `build_spot_base_tile`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `tile_or_overlay`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Purpose: Neutral pad under towers. Gameplay read: Warm gold rim at light 100; supports regional darkness multiply overlay. Output: 128×128 tile as a complete no-green full-canvas asset. Pivot: bottom-center. ---

## Asset-type contract

Create one tile-aligned sprite or overlay. Keep edges clean and readable at zoom-out.

## Exact technical export contract

- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/tilesets/`. Use stable asset ID `build_spot_base_tile` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_flame_of_azar

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `card_flame_of_azar`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Purpose: Fate card art — matches code card_id. Gameplay read: Fire boon top, curse band bottom — flame of Azar motif. Output: Card illustration inside frame safe area as a complete no-green full-canvas asset. ---

## Asset-type contract

Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract

- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_flame_of_azar` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — hero_portrait_rostam

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `hero_portrait_rostam`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `character_base`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Rostam-specific identity markers — mandatory:

- He must read instantly as **Rostam**, the legendary champion of the Shahnameh.
- Give him a powerful mature heroic presence, commanding face, dark beard, and unmistakably Persian epic stature.
- Include clear **Babr-e Bayan / tiger-or-leopard motif** influence in textile or armor details.
- His loadout and symbolism should support **sword + lasso + heroic mace association** with Iranian epic armor and rich Persian textile accents.
- He must never read as a generic palace guard, MMO warrior, or random medieval soldier.

Portrait identity rule:

- The portrait must clearly communicate **Shahnameh identity, Persian epic costume language, and Iranian heroic facial character** rather than a generic fantasy portrait.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Purpose: HUD bottom-left portrait. Output: 256×256 bust as a complete no-green full-canvas asset. Pivot: center. ---

## Asset-type contract

Create one isolated full-body sprite unless the asset is explicitly a bust/codex portrait. Keep the full silhouette visible with safe padding. Use bottom-center pivot intent for gameplay sprites. Do not bake a ground plane or cast shadow into the sprite.

## Exact technical export contract

- Exact canvas: 256×256px.
- Grid: 1 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/characters/`. Use stable asset ID `hero_portrait_rostam` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette.

---

# READY-TO-PASTE IMAGE PROMPT — hud_icon_atlas_core

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `hud_icon_atlas_core`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon_atlas`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Purpose: Core battle icons (no text). Generate as atlas or one icon per request. Icons: gold, sacred_fire, lives, morale, farr, hero_energy, rewind, forge, pause, resume, speed, settings, cleanse, brazier, qanat, tether, upgrade, sell, repair, reposition, purge, inspect, burn, slow, stun, armor_break, corruption_warning, hijacked, purified, boss, objective_active, objective_complete, objective_failed. Output: 128×128 per icon as a complete no-green full-canvas asset or combined atlas. Pivot: center. ---

## Asset-type contract

Create an icon atlas with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract

- Exact canvas: 1024×640px.
- Grid: 8 columns × 5 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `hud_icon_atlas_core` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — regional_darkness_overlay

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `regional_darkness_overlay`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `tile_or_overlay`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Purpose: Per build-spot multiply sprite (MapLightManager). Gameplay read: Purple-black darkness, not flat gray; alpha scales with light loss. Output: 128×128 soft overlay as a complete no-green full-canvas asset. Pivot: center. ---

## Asset-type contract

Create one tile-aligned sprite or overlay. Keep edges clean and readable at zoom-out.

## Exact technical export contract

- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/tilesets/`. Use stable asset ID `regional_darkness_overlay` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — tileset_woodland

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `tileset_woodland`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `tileset_atlas`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Purpose: Khan 1 terrain atlas. Gameplay read: Grass, meadow flowers, forest floor, stream, reeds, dirt path, path turns, stone path, mossy rock, cliff edges, corruption and Sacred-Light transition tiles. Output: 1024×1024 atlas, 8×8 × 128² as a complete no-green full-canvas asset with exact cell alignment. Pivot: tile center. Mobile readability notes: Path tiles clearly distinct from grass at zoom-out. ---

## Asset-type contract

Create a seamless tileset atlas with exactly 8 columns × 8 rows of 128×128px tiles. Every edge-transition tile must tile cleanly. Include no text or labels.

## Exact technical export contract

- Exact canvas: 1024×1024px.
- Grid: 8 columns × 8 rows. Cell size: 128×128px.
- Pivot intent for Godot: tile-center.
- Reserve tile boundaries exactly at multiples of 128px; make edge transitions seamless.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/tilesets/`. Use stable asset ID `tileset_woodland` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_battle_hud

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `ui_battle_hud`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_asset`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Purpose: Production battle HUD (replaces prototype). Gameplay read: Progressive disclosure — always: Lives, Gold, Sacred Fire, wave, pause, speed, hero portrait/HP/energy/skill, 4 tower cards, contextual tower action. Contextual slots empty or icon-only for Morale/Farr/Forge/etc. Output: 4096×2304 mockup as a complete no-green full-canvas asset — no readable text. Production pass: Atlases + transparent chrome. ---

## Asset-type contract

Create a landscape-mobile UI asset or illustration with ornate Persian-manuscript influence, blank plaques, and icon slots only. Do not bake readable text into the art. Keep important UI-safe areas uncluttered.

## Exact technical export contract

- Exact canvas: 4096×2304px.
- Grid: 1 columns × 1 rows. Cell size: 4096×2304px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/`. Use stable asset ID `ui_battle_hud` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_company_splash

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `ui_company_splash`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `illustration`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Purpose: Boot splash (P2). Output: 1920×1080 or project splash size, logo-free, ornamental border only. ---

## Asset-type contract

Create a landscape-mobile UI asset or illustration with ornate Persian-manuscript influence, blank plaques, and icon slots only. Do not bake readable text into the art. Keep important UI-safe areas uncluttered.

## Exact technical export contract

- Exact canvas: 1920×1080px.
- Grid: 1 columns × 1 rows. Cell size: 1920×1080px.
- Pivot intent for Godot: n/a.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/screens/`. Use stable asset ID `ui_company_splash` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_fate_card_frame

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `ui_fate_card_frame`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_asset`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Purpose: Fate draft card chrome (boon top / curse bottom split). Output: 512×768 frame as a complete no-green full-canvas asset, no text. ---

## Asset-type contract

Create a landscape-mobile UI asset or illustration with ornate Persian-manuscript influence, blank plaques, and icon slots only. Do not bake readable text into the art. Keep important UI-safe areas uncluttered.

## Exact technical export contract

- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/`. Use stable asset ID `ui_fate_card_frame` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_main_menu_background

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `ui_main_menu_background`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `illustration`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Purpose: Main menu BG (P2). Output: 4096×2304 landscape illustration, a deliberate non-chroma full-canvas base or full bleed with safe UI zone marked. ---

## Asset-type contract

Create a landscape-mobile UI asset or illustration with ornate Persian-manuscript influence, blank plaques, and icon slots only. Do not bake readable text into the art. Keep important UI-safe areas uncluttered.

## Exact technical export contract

- Exact canvas: 4096×2304px.
- Grid: 1 columns × 1 rows. Cell size: 4096×2304px.
- Pivot intent for Godot: n/a.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/screens/`. Use stable asset ID `ui_main_menu_background` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_pardeh_break_frame

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `ui_pardeh_break_frame`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_asset`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Purpose: Pardeh Break overlay after wave 4. Output: Ornate curtain-break frame, 4096×2304 safe area as a complete no-green full-canvas asset, no text. Pivot: N/A. ---

## Asset-type contract

Create a landscape-mobile UI asset or illustration with ornate Persian-manuscript influence, blank plaques, and icon slots only. Do not bake readable text into the art. Keep important UI-safe areas uncluttered.

## Exact technical export contract

- Exact canvas: 4096×2304px.
- Grid: 1 columns × 1 rows. Cell size: 4096×2304px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/`. Use stable asset ID `ui_pardeh_break_frame` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_results_defeat_frame

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `ui_results_defeat_frame`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_asset`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Purpose: Defeat results — must explain loss clearly when text added in engine. Output: As victory, somber crimson/teal balance. ---

## Asset-type contract

Create a landscape-mobile UI asset or illustration with ornate Persian-manuscript influence, blank plaques, and icon slots only. Do not bake readable text into the art. Keep important UI-safe areas uncluttered.

## Exact technical export contract

- Exact canvas: 4096×2304px.
- Grid: 1 columns × 1 rows. Cell size: 4096×2304px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/`. Use stable asset ID `ui_results_defeat_frame` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_results_victory_frame

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `ui_results_victory_frame`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_asset`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Purpose: Victory results panel. Output: Manuscript border panel 2048×1024 as a complete no-green full-canvas asset, no text. ---

## Asset-type contract

Create a landscape-mobile UI asset or illustration with ornate Persian-manuscript influence, blank plaques, and icon slots only. Do not bake readable text into the art. Keep important UI-safe areas uncluttered.

## Exact technical export contract

- Exact canvas: 2048×1024px.
- Grid: 1 columns × 1 rows. Cell size: 2048×1024px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/`. Use stable asset ID `ui_results_victory_frame` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_tutorial_overlay_panels

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `ui_tutorial_overlay_panels`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_asset`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Purpose: First-launch tutorial (tutorial_overlay.tscn). Output: Callout plaques and arrow motifs as a complete no-green full-canvas asset, no readable text. ---

## Asset-type contract

Create a landscape-mobile UI asset or illustration with ornate Persian-manuscript influence, blank plaques, and icon slots only. Do not bake readable text into the art. Keep important UI-safe areas uncluttered.

## Exact technical export contract

- Exact canvas: 4096×2304px.
- Grid: 1 columns × 1 rows. Cell size: 4096×2304px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/`. Use stable asset ID `ui_tutorial_overlay_panels` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_world_map_node_states

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `ui_world_map_node_states`
- Project phase: Phase 1 — Khan 1 Vertical Slice
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon_atlas`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Purpose: Campaign map nodes. Output: Three icons — locked, unlocked, complete — 256×256 each as a complete no-green full-canvas asset. ---

## Asset-type contract

Create an icon atlas with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract

- Exact canvas: 768×256px.
- Grid: 3 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `ui_world_map_node_states` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.
