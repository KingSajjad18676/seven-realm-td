# ALL READY-TO-PASTE IMAGE PROMPTS — phase_00_visual_lock

---

# READY-TO-PASTE IMAGE PROMPT — hero_rostam

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `hero_rostam`
- Project phase: Phase 0 — Visual Lock
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_base`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Rostam-specific identity markers — mandatory:

- He must read instantly as **Rostam**, the legendary champion of the Shahnameh.
- Give him a powerful mature heroic presence, commanding face, dark beard, and unmistakably Persian epic stature.
- Include clear **Babr-e Bayan / tiger-or-leopard motif** influence in textile or armor details.
- His loadout and symbolism should support **sword + lasso + heroic mace association** with Iranian epic armor and rich Persian textile accents.
- He must never read as a generic palace guard, MMO warrior, or random medieval soldier.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Purpose: Style anchor for entire game; frontline playable hero. Gameplay read: Broad heroic silhouette; mature commanding face; bronze-and-gold armor; teal/crimson textile panels; sword, lasso, restrained ox-headed mace; subtle tiger/leopard textile reference — not Viking or European knight. Output: Single isolated base design on #00FF00. Canvas/grid: 256×256 cell (fits later strips). Pivot: bottom-center. Animation states: Base only — strips are separate assets. Mobile readability notes: Must read clearly at ~15% screen height on landscape phone.

## Asset-type contract

Create one isolated full-body sprite unless the asset is explicitly a bust/codex portrait. Keep the full silhouette visible with safe padding. Use bottom-center pivot intent for gameplay sprites. Do not bake a ground plane or cast shadow into the sprite.

## Exact technical export contract

- Exact canvas: 256×256px.
- Grid: 1 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `hero_rostam` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette.

---

# READY-TO-PASTE IMAGE PROMPT — hero_rostam_basic_attack

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `hero_rostam_basic_attack`
- Project phase: Phase 0 — Visual Lock
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Rostam-specific identity markers — mandatory:

- He must read instantly as **Rostam**, the legendary champion of the Shahnameh.
- Give him a powerful mature heroic presence, commanding face, dark beard, and unmistakably Persian epic stature.
- Include clear **Babr-e Bayan / tiger-or-leopard motif** influence in textile or armor details.
- His loadout and symbolism should support **sword + lasso + heroic mace association** with Iranian epic armor and rich Persian textile accents.
- He must never read as a generic palace guard, MMO warrior, or random medieval soldier.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Animation strip for hero_rostam. Action/state: basic_attack. Preserve the exact approved base design, costume, proportions, material colors, and lighting from hero_rostam in every frame. Mace or sword anticipation, impact, recovery. Parent design context: Purpose: Style anchor for entire game; frontline playable hero. Gameplay read: Broad heroic silhouette; mature commanding face; bronze-and-gold armor; teal/crimson textile panels; sword, lasso, restrained ox-headed mace; subtle tiger/leopard textile reference — not Viking or European knight. Output: Single isolated base design on #00FF00. Canvas/grid: 256×256 cell (fits later strips). Pivot: bottom-center. Animation states: Base only — strips are separate assets. Mobile readability notes: Must read clearly at ~15% screen height on landscape phone.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `hero_rostam`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `hero_rostam_basic_attack` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — hero_rostam_idle

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `hero_rostam_idle`
- Project phase: Phase 0 — Visual Lock
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Rostam-specific identity markers — mandatory:

- He must read instantly as **Rostam**, the legendary champion of the Shahnameh.
- Give him a powerful mature heroic presence, commanding face, dark beard, and unmistakably Persian epic stature.
- Include clear **Babr-e Bayan / tiger-or-leopard motif** influence in textile or armor details.
- His loadout and symbolism should support **sword + lasso + heroic mace association** with Iranian epic armor and rich Persian textile accents.
- He must never read as a generic palace guard, MMO warrior, or random medieval soldier.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Animation strip for hero_rostam. Action/state: idle. Preserve the exact approved base design, costume, proportions, material colors, and lighting from hero_rostam in every frame. Subtle breathing; feet planted. Parent design context: Purpose: Style anchor for entire game; frontline playable hero. Gameplay read: Broad heroic silhouette; mature commanding face; bronze-and-gold armor; teal/crimson textile panels; sword, lasso, restrained ox-headed mace; subtle tiger/leopard textile reference — not Viking or European knight. Output: Single isolated base design on #00FF00. Canvas/grid: 256×256 cell (fits later strips). Pivot: bottom-center. Animation states: Base only — strips are separate assets. Mobile readability notes: Must read clearly at ~15% screen height on landscape phone.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `hero_rostam`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `hero_rostam_idle` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — hero_rostam_walk

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `hero_rostam_walk`
- Project phase: Phase 0 — Visual Lock
- Deliverable mode: **GREEN-BACKGROUND GODOT SPRITE GRID**
- Asset class: `character_animation`

## Background policy — highest priority

This is an isolated gameplay sprite or sprite-sheet asset. Use a **solid opaque chroma-green background exactly `#00FF00`** in every unused pixel region. Do **not** use transparency or alpha background. Preserve the exact sprite-sheet canvas and conceptual cell grid. Keep the subject fully visible with safe padding inside each cell. Do not crop any body part, tower part, effect edge, or prop edge. Do not draw visible guide lines into the final exported image; the cells must be aligned mathematically, not separated by printed lines. Keep clean edges with no green spill, green fringe, green outline, or green cast shadow.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Mandatory Shahnameh character reference — highest priority

This asset must visibly belong to the world of **Ferdowsi's Shahnameh**. Do **not** design a generic fantasy soldier, random mobile-RPG hero, anonymous medieval guard, or generic Western warrior.

Character-design rules:

- Base the character on **Persian epic / Iranian heroic design language** filtered through **Shahnameh manuscript imagination** and **Persian miniature painting**, adapted into clean readable 2D game art.
- Human or human-like figures must use **Iranian/Persian-inspired costume and armor**: lamellar or scale armor, bronze/copper/gold/brass plates, quilted underlayers, long decorated tunic panels, sash belts, fitted trousers, leather boots, armguards, and Persian-style conical or rounded helmets.
- Use **Persian ornamental motifs** where appropriate: sun-disc medallions, rosettes, floral-geometric trims, engraved metalwork, lion, tiger, leopard, horse, or Simurgh-inspired motifs.
- Faces must feel **Iranian/Persian and heroic**: noble features, strong brows, expressive almond-shaped eyes, dark hair, beard or moustache when appropriate, and a dignified epic presence. Avoid blank mannequin faces.
- The overall silhouette must feel **Shahnameh / Persian epic**, not European knight, crusader, Viking, Roman legionary, samurai, or generic fantasy guard.
- If the subject is a mythic beast, companion, boss, or monster, its design must still be filtered through **Iranian epic / Shahnameh aesthetics** rather than generic Western monster design.
- Corruption, magic, darkness, or boss transformations are only **overlays**; they must never erase the underlying Shahnameh / Persian identity.

Rostam-specific identity markers — mandatory:

- He must read instantly as **Rostam**, the legendary champion of the Shahnameh.
- Give him a powerful mature heroic presence, commanding face, dark beard, and unmistakably Persian epic stature.
- Include clear **Babr-e Bayan / tiger-or-leopard motif** influence in textile or armor details.
- His loadout and symbolism should support **sword + lasso + heroic mace association** with Iranian epic armor and rich Persian textile accents.
- He must never read as a generic palace guard, MMO warrior, or random medieval soldier.

## STRICT SPRITE-SHEET CELL ISOLATION — highest priority

Treat this output as a **technical Godot sprite sheet**, not as one continuous cinematic illustration.

Mandatory cell-isolation rules:

- Render **exactly one complete opaque sprite pose inside each cell**.
- Each cell must look like a separate clean cut-out placed independently on a flat green screen.
- Do **not** blend neighboring frames together.
- Do **not** paint transitional bodies, extra in-between figures, translucent duplicate figures, motion ghosts, afterimages, motion blur, speed smears, fog, dust haze, soft background gradients, or cinematic action trails between cells.
- Pose changes happen **only from one cell to the next**. Never interpolate visually across cell boundaries.
- Keep every body part, weapon, tower component, and costume edge fully inside its own cell.
- Leave a minimum **12px pure-green safety margin** at the left and right edges of every cell and a minimum **8px pure-green safety margin** at the top and bottom edges whenever the silhouette allows it.
- Use the same scale, same floor baseline, same bottom-center pivot, same camera angle, same costume, and same lighting in every cell.
- Fill every pixel outside the sprite silhouette with one perfectly uniform solid color: **`#00FF00`**. No pale green, gray-green, olive, sage, textured green, gradient green, vignette, shadow wash, or atmospheric tint.
- Do not draw a continuous floor strip, scenery, horizon, or scene background across the sheet.
- Do not add sparkle icons, watermark-like stars, decorative corner marks, labels, or UI symbols.

Acceptance test: when the canvas is sliced into the requested cells, every cell must work as a clean independent game frame with a pure `#00FF00` background and no pixels from adjacent poses.

## Asset-specific direction

This asset must read unmistakably as part of the **Shahnameh / Persian epic world**. Prioritize Persian identity over generic fantasy readability whenever there is any conflict.

Animation strip for hero_rostam. Action/state: walk. Preserve the exact approved base design, costume, proportions, material colors, and lighting from hero_rostam in every frame. Controlled stride facing screen-right. Parent design context: Purpose: Style anchor for entire game; frontline playable hero. Gameplay read: Broad heroic silhouette; mature commanding face; bronze-and-gold armor; teal/crimson textile panels; sword, lasso, restrained ox-headed mace; subtle tiger/leopard textile reference — not Viking or European knight. Output: Single isolated base design on #00FF00. Canvas/grid: 256×256 cell (fits later strips). Pivot: bottom-center. Animation states: Base only — strips are separate assets. Mobile readability notes: Must read clearly at ~15% screen height on landscape phone.

## Asset-type contract

Create a horizontal animation strip with exactly 8 equal cells and 1 row. Every cell is exactly 256×256px. Animate left-to-right. Do not merge poses. Do not overlap cells. Preserve identical scale, costume, materials, perspective, and lighting in every cell.

## Exact technical export contract

- Exact canvas: 2048×256px.
- Grid: 8 columns × 1 rows. Cell size: 256×256px.
- Pivot intent for Godot: bottom-center.
- Match approved parent asset exactly: `hero_rostam`.
- Frame order: left-to-right. Use 8 distinct sequential frames unless the asset specification explicitly requests fewer. Place the subject consistently inside every cell; no cell overflow or overlap.
- Keep the virtual floor line and bottom-center anchor identical in every cell; no foot sliding except deliberate locomotion.
- GREEN SPRITE EXPORT: use solid opaque chroma green exactly `#00FF00` in background
- Godot target folder: `art/characters/`. Use stable asset ID `hero_rostam_walk` as the export basename.

## Required result

A continuous scene or blended animation preview is invalid. The only acceptable result is a clean technical sprite sheet with one isolated pose per cell.

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames, generic medieval guard, generic mobile-game warrior, generic teal-armored soldier, anonymous fantasy mercenary, faceless mannequin hero, non-Persian costume language, culturally generic armor silhouette, pale green background, sage green background, gray-green background, olive background, background gradient, continuous scene background, continuous floor strip, blended sprite frames, translucent frame ghosts, duplicate in-between bodies, afterimages, cinematic motion trails, pose interpolation across cells, cross-cell blur, cross-cell overlap, corner sparkle icon, decorative corner star.

---

# READY-TO-PASTE IMAGE PROMPT — map_khan_01_lion_rakhsh

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `map_khan_01_lion_rakhsh`
- Project phase: Phase 0 — Visual Lock
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `map_blueprint`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Purpose: Khan 1 battlefield — technical and readability proof. Narrative anchor: Rakhsh confronts a lion while Rostam rests (Shahnameh woodland meadow). Gameplay read: - Enemy entrance upper-right; player gate lower-left - Two-tile-wide winding path - Central 6×6 lion arena - Eight 2×2 build pads - Three regional-light sectors - One Sacred Fire brazier point - One hero-rest marker Output: Generate one map layer per request as a complete no-green full-canvas asset (128×128 tiles, 32×18 grid). Layers: terrain, path, build_pads, light_sectors, corruption_mask, collision, camera_anchors. Canvas/grid: 4096×2304 logical (32×18 × 128) per full composite preview OR single layer tile grid. Pivot: tile top-left for TileMap import. Animation states: Static tiles. Mobile readability notes: Route understandable in 2 seconds; pads high contrast vs grass. Production pass: full-size PNG layers that preserve the entire rectangular coordinate space; do not crop active regions. ---

## Asset-type contract

Create a full map blueprint preview aligned to the stated tile grid. Preserve tile boundaries and gameplay readability. This blueprint is the coordinate lock for all separate layer exports.

## Exact technical export contract

- Exact canvas: 4096×2304px.
- Grid: 32 columns × 18 rows. Cell size: 128×128px.
- Pivot intent for Godot: top-left.
- Tile origin is top-left. Keep all tile coordinates exact and stable across exports.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/maps/`. Use stable asset ID `map_khan_01_lion_rakhsh` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — map_khan_01_lion_rakhsh\_\_build_pads

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `map_khan_01_lion_rakhsh__build_pads`
- Project phase: Phase 0 — Visual Lock
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `map_layer`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Godot TileMap export layer build_pads for map_khan_01_lion_rakhsh. Generate only this one layer. Keep coordinates aligned to the same 32×18 tile blueprint and do not move route, pads, arenas, or sector boundaries between layer requests. Map context: Purpose: Khan 1 battlefield — technical and readability proof. Narrative anchor: Rakhsh confronts a lion while Rostam rests (Shahnameh woodland meadow). Gameplay read: - Enemy entrance upper-right; player gate lower-left - Two-tile-wide winding path - Central 6×6 lion arena - Eight 2×2 build pads - Three regional-light sectors - One Sacred Fire brazier point - One hero-rest marker Output: Generate one map layer per request as a complete no-green full-canvas asset (128×128 tiles, 32×18 grid). Layers: terrain, path, build_pads, light_sectors, corruption_mask, collision, camera_anchors. Canvas/grid: 4096×2304 logical (32×18 × 128) per full composite preview OR single layer tile grid. Pivot: tile top-left for TileMap import. Animation states: Static tiles. Mobile readability notes: Route understandable in 2 seconds; pads high contrast vs grass. Production pass: full-size PNG layers that preserve the entire rectangular coordinate space; do not crop active regions. --- Show build pads only, with clear tower-placement footprints and high contrast against terrain.

## Asset-type contract

Create only one Godot TileMap-aligned PNG layer. Preserve exact tile coordinates from the locked map blueprint. Do not combine layers. Empty regions must remain clean for chroma removal or alpha export.

## Exact technical export contract

- Exact canvas: 4096×2304px.
- Grid: 32 columns × 18 rows. Cell size: 128×128px.
- Pivot intent for Godot: top-left.
- Match approved parent asset exactly: `map_khan_01_lion_rakhsh`.
- Export layer name: `build_pads`.
- Tile origin is top-left. Keep all tile coordinates exact and stable across exports.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/maps/`. Use stable asset ID `map_khan_01_lion_rakhsh__build_pads` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — map_khan_01_lion_rakhsh\_\_camera_anchors

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `map_khan_01_lion_rakhsh__camera_anchors`
- Project phase: Phase 0 — Visual Lock
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `map_layer`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Godot TileMap export layer camera_anchors for map_khan_01_lion_rakhsh. Generate only this one layer. Keep coordinates aligned to the same 32×18 tile blueprint and do not move route, pads, arenas, or sector boundaries between layer requests. Map context: Purpose: Khan 1 battlefield — technical and readability proof. Narrative anchor: Rakhsh confronts a lion while Rostam rests (Shahnameh woodland meadow). Gameplay read: - Enemy entrance upper-right; player gate lower-left - Two-tile-wide winding path - Central 6×6 lion arena - Eight 2×2 build pads - Three regional-light sectors - One Sacred Fire brazier point - One hero-rest marker Output: Generate one map layer per request as a complete no-green full-canvas asset (128×128 tiles, 32×18 grid). Layers: terrain, path, build_pads, light_sectors, corruption_mask, collision, camera_anchors. Canvas/grid: 4096×2304 logical (32×18 × 128) per full composite preview OR single layer tile grid. Pivot: tile top-left for TileMap import. Animation states: Static tiles. Mobile readability notes: Route understandable in 2 seconds; pads high contrast vs grass. Production pass: full-size PNG layers that preserve the entire rectangular coordinate space; do not crop active regions. --- Show camera-anchor markers only as simple engine-review sockets without labels; remove markers from final player-facing art.

## Asset-type contract

Create only one Godot TileMap-aligned PNG layer. Preserve exact tile coordinates from the locked map blueprint. Do not combine layers. Empty regions must remain clean for chroma removal or alpha export.

## Exact technical export contract

- Exact canvas: 4096×2304px.
- Grid: 32 columns × 18 rows. Cell size: 128×128px.
- Pivot intent for Godot: top-left.
- Match approved parent asset exactly: `map_khan_01_lion_rakhsh`.
- Export layer name: `camera_anchors`.
- Tile origin is top-left. Keep all tile coordinates exact and stable across exports.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/maps/`. Use stable asset ID `map_khan_01_lion_rakhsh__camera_anchors` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — map_khan_01_lion_rakhsh\_\_collision

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `map_khan_01_lion_rakhsh__collision`
- Project phase: Phase 0 — Visual Lock
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `map_layer`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Godot TileMap export layer collision for map_khan_01_lion_rakhsh. Generate only this one layer. Keep coordinates aligned to the same 32×18 tile blueprint and do not move route, pads, arenas, or sector boundaries between layer requests. Map context: Purpose: Khan 1 battlefield — technical and readability proof. Narrative anchor: Rakhsh confronts a lion while Rostam rests (Shahnameh woodland meadow). Gameplay read: - Enemy entrance upper-right; player gate lower-left - Two-tile-wide winding path - Central 6×6 lion arena - Eight 2×2 build pads - Three regional-light sectors - One Sacred Fire brazier point - One hero-rest marker Output: Generate one map layer per request as a complete no-green full-canvas asset (128×128 tiles, 32×18 grid). Layers: terrain, path, build_pads, light_sectors, corruption_mask, collision, camera_anchors. Canvas/grid: 4096×2304 logical (32×18 × 128) per full composite preview OR single layer tile grid. Pivot: tile top-left for TileMap import. Animation states: Static tiles. Mobile readability notes: Route understandable in 2 seconds; pads high contrast vs grass. Production pass: full-size PNG layers that preserve the entire rectangular coordinate space; do not crop active regions. --- Show collision mask shapes only as clean binary-style tile regions suitable for engineering review; no decorative art.

## Asset-type contract

Create only one Godot TileMap-aligned PNG layer. Preserve exact tile coordinates from the locked map blueprint. Do not combine layers. Empty regions must remain clean for chroma removal or alpha export.

## Exact technical export contract

- Exact canvas: 4096×2304px.
- Grid: 32 columns × 18 rows. Cell size: 128×128px.
- Pivot intent for Godot: top-left.
- Match approved parent asset exactly: `map_khan_01_lion_rakhsh`.
- Export layer name: `collision`.
- Tile origin is top-left. Keep all tile coordinates exact and stable across exports.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/maps/`. Use stable asset ID `map_khan_01_lion_rakhsh__collision` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — map_khan_01_lion_rakhsh\_\_corruption_mask

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `map_khan_01_lion_rakhsh__corruption_mask`
- Project phase: Phase 0 — Visual Lock
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `map_layer`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Godot TileMap export layer corruption_mask for map_khan_01_lion_rakhsh. Generate only this one layer. Keep coordinates aligned to the same 32×18 tile blueprint and do not move route, pads, arenas, or sector boundaries between layer requests. Map context: Purpose: Khan 1 battlefield — technical and readability proof. Narrative anchor: Rakhsh confronts a lion while Rostam rests (Shahnameh woodland meadow). Gameplay read: - Enemy entrance upper-right; player gate lower-left - Two-tile-wide winding path - Central 6×6 lion arena - Eight 2×2 build pads - Three regional-light sectors - One Sacred Fire brazier point - One hero-rest marker Output: Generate one map layer per request as a complete no-green full-canvas asset (128×128 tiles, 32×18 grid). Layers: terrain, path, build_pads, light_sectors, corruption_mask, collision, camera_anchors. Canvas/grid: 4096×2304 logical (32×18 × 128) per full composite preview OR single layer tile grid. Pivot: tile top-left for TileMap import. Animation states: Static tiles. Mobile readability notes: Route understandable in 2 seconds; pads high contrast vs grass. Production pass: full-size PNG layers that preserve the entire rectangular coordinate space; do not crop active regions. --- Show corruption-mask overlay only: restrained cold-blue, charcoal, and shadow-violet veins.

## Asset-type contract

Create only one Godot TileMap-aligned PNG layer. Preserve exact tile coordinates from the locked map blueprint. Do not combine layers. Empty regions must remain clean for chroma removal or alpha export.

## Exact technical export contract

- Exact canvas: 4096×2304px.
- Grid: 32 columns × 18 rows. Cell size: 128×128px.
- Pivot intent for Godot: top-left.
- Match approved parent asset exactly: `map_khan_01_lion_rakhsh`.
- Export layer name: `corruption_mask`.
- Tile origin is top-left. Keep all tile coordinates exact and stable across exports.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/maps/`. Use stable asset ID `map_khan_01_lion_rakhsh__corruption_mask` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — map_khan_01_lion_rakhsh\_\_light_sectors

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `map_khan_01_lion_rakhsh__light_sectors`
- Project phase: Phase 0 — Visual Lock
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `map_layer`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Godot TileMap export layer light_sectors for map_khan_01_lion_rakhsh. Generate only this one layer. Keep coordinates aligned to the same 32×18 tile blueprint and do not move route, pads, arenas, or sector boundaries between layer requests. Map context: Purpose: Khan 1 battlefield — technical and readability proof. Narrative anchor: Rakhsh confronts a lion while Rostam rests (Shahnameh woodland meadow). Gameplay read: - Enemy entrance upper-right; player gate lower-left - Two-tile-wide winding path - Central 6×6 lion arena - Eight 2×2 build pads - Three regional-light sectors - One Sacred Fire brazier point - One hero-rest marker Output: Generate one map layer per request as a complete no-green full-canvas asset (128×128 tiles, 32×18 grid). Layers: terrain, path, build_pads, light_sectors, corruption_mask, collision, camera_anchors. Canvas/grid: 4096×2304 logical (32×18 × 128) per full composite preview OR single layer tile grid. Pivot: tile top-left for TileMap import. Animation states: Static tiles. Mobile readability notes: Route understandable in 2 seconds; pads high contrast vs grass. Production pass: full-size PNG layers that preserve the entire rectangular coordinate space; do not crop active regions. --- Show regional-light sector overlay shapes only; keep sector boundaries readable but non-textual.

## Asset-type contract

Create only one Godot TileMap-aligned PNG layer. Preserve exact tile coordinates from the locked map blueprint. Do not combine layers. Empty regions must remain clean for chroma removal or alpha export.

## Exact technical export contract

- Exact canvas: 4096×2304px.
- Grid: 32 columns × 18 rows. Cell size: 128×128px.
- Pivot intent for Godot: top-left.
- Match approved parent asset exactly: `map_khan_01_lion_rakhsh`.
- Export layer name: `light_sectors`.
- Tile origin is top-left. Keep all tile coordinates exact and stable across exports.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/maps/`. Use stable asset ID `map_khan_01_lion_rakhsh__light_sectors` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — map_khan_01_lion_rakhsh\_\_path

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `map_khan_01_lion_rakhsh__path`
- Project phase: Phase 0 — Visual Lock
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `map_layer`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Godot TileMap export layer path for map_khan_01_lion_rakhsh. Generate only this one layer. Keep coordinates aligned to the same 32×18 tile blueprint and do not move route, pads, arenas, or sector boundaries between layer requests. Map context: Purpose: Khan 1 battlefield — technical and readability proof. Narrative anchor: Rakhsh confronts a lion while Rostam rests (Shahnameh woodland meadow). Gameplay read: - Enemy entrance upper-right; player gate lower-left - Two-tile-wide winding path - Central 6×6 lion arena - Eight 2×2 build pads - Three regional-light sectors - One Sacred Fire brazier point - One hero-rest marker Output: Generate one map layer per request as a complete no-green full-canvas asset (128×128 tiles, 32×18 grid). Layers: terrain, path, build_pads, light_sectors, corruption_mask, collision, camera_anchors. Canvas/grid: 4096×2304 logical (32×18 × 128) per full composite preview OR single layer tile grid. Pivot: tile top-left for TileMap import. Animation states: Static tiles. Mobile readability notes: Route understandable in 2 seconds; pads high contrast vs grass. Production pass: full-size PNG layers that preserve the entire rectangular coordinate space; do not crop active regions. --- Show enemy route tiles only; use transparent/green empty regions. Route must be readable instantly at mobile zoom.

## Asset-type contract

Create only one Godot TileMap-aligned PNG layer. Preserve exact tile coordinates from the locked map blueprint. Do not combine layers. Empty regions must remain clean for chroma removal or alpha export.

## Exact technical export contract

- Exact canvas: 4096×2304px.
- Grid: 32 columns × 18 rows. Cell size: 128×128px.
- Pivot intent for Godot: top-left.
- Match approved parent asset exactly: `map_khan_01_lion_rakhsh`.
- Export layer name: `path`.
- Tile origin is top-left. Keep all tile coordinates exact and stable across exports.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/maps/`. Use stable asset ID `map_khan_01_lion_rakhsh__path` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — map_khan_01_lion_rakhsh\_\_terrain

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `map_khan_01_lion_rakhsh__terrain`
- Project phase: Phase 0 — Visual Lock
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `map_layer`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Godot TileMap export layer terrain for map_khan_01_lion_rakhsh. Generate only this one layer. Keep coordinates aligned to the same 32×18 tile blueprint and do not move route, pads, arenas, or sector boundaries between layer requests. Map context: Purpose: Khan 1 battlefield — technical and readability proof. Narrative anchor: Rakhsh confronts a lion while Rostam rests (Shahnameh woodland meadow). Gameplay read: - Enemy entrance upper-right; player gate lower-left - Two-tile-wide winding path - Central 6×6 lion arena - Eight 2×2 build pads - Three regional-light sectors - One Sacred Fire brazier point - One hero-rest marker Output: Generate one map layer per request as a complete no-green full-canvas asset (128×128 tiles, 32×18 grid). Layers: terrain, path, build_pads, light_sectors, corruption_mask, collision, camera_anchors. Canvas/grid: 4096×2304 logical (32×18 × 128) per full composite preview OR single layer tile grid. Pivot: tile top-left for TileMap import. Animation states: Static tiles. Mobile readability notes: Route understandable in 2 seconds; pads high contrast vs grass. Production pass: full-size PNG layers that preserve the entire rectangular coordinate space; do not crop active regions. --- Fill the whole terrain layer with biome ground, cliffs, water, and environment base tiles; no gameplay markers.

## Asset-type contract

Create only one Godot TileMap-aligned PNG layer. Preserve exact tile coordinates from the locked map blueprint. Do not combine layers. Empty regions must remain clean for chroma removal or alpha export.

## Exact technical export contract

- Exact canvas: 4096×2304px.
- Grid: 32 columns × 18 rows. Cell size: 128×128px.
- Pivot intent for Godot: top-left.
- Match approved parent asset exactly: `map_khan_01_lion_rakhsh`.
- Export layer name: `terrain`.
- Tile origin is top-left. Keep all tile coordinates exact and stable across exports.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/maps/`. Use stable asset ID `map_khan_01_lion_rakhsh__terrain` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_battle_hud_prototype

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity

- Stable asset ID: `ui_battle_hud_prototype`
- Project phase: Phase 0 — Visual Lock
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_asset`

## Background policy — highest priority

This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system

Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction

Purpose: Validate HUD hierarchy and touch zones before production art. Gameplay read: Calm vertical-slice layout — not every future system visible. Output: Landscape UI mockup as a complete no-green full-canvas asset OR layered panel export per zone request. Canvas/grid: 4096×2304 landscape full mockup, or individual zone panels as specified. Pivot: N/A (UI). Required zones (no readable text — icons/blank plaques only): - Top-left: Lives, Gold, Sacred Fire, Wave placeholders - Top-right: pause, speed, settings, cleanse - Bottom-left: hero portrait slot, HP, energy, skill, Tether - Bottom-center: four starter tower card slots - Bottom-right: contextual tower action slot - Center: alert-banner safe area (empty) Mobile readability notes: One-thumb and two-thumb reachable corners; Sacred Fire flame icon distinguishable from Gold. Production pass: Separate atlases with transparent UI chrome; no baked text. ---

## Asset-type contract

Create a landscape-mobile UI asset or illustration with ornate Persian-manuscript influence, blank plaques, and icon slots only. Do not bake readable text into the art. Keep important UI-safe areas uncluttered.

## Exact technical export contract

- Exact canvas: 4096×2304px.
- Grid: 1 columns × 1 rows. Cell size: 4096×2304px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/`. Use stable asset ID `ui_battle_hud_prototype` as the export basename.

## Required result

Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt

Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.
