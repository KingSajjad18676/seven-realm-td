# ALL READY-TO-PASTE IMAGE PROMPTS — phase_03_roguelite_cards_relics

---

# READY-TO-PASTE IMAGE PROMPT — card_ahriman_bargain

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_ahriman_bargain`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Tempting gold hand offer. Curse: Shadow contract serpent coil bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_ahriman_bargain` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_arash_precision

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_arash_precision`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Arrow arc to sun disk. Curse: Broken arrow bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_arash_precision` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_ashes_of_renewal

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_ashes_of_renewal`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Ash transforming to flame phoenix spark. Curse: Cold ash pile bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_ashes_of_renewal` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_blackened_crown

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_blackened_crown`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Cleansed crown shine. Curse: Blackened crown drip bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_blackened_crown` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_broken_clock

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_broken_clock`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Sun disk time blessing (Zervan). Curse: Cracked dial shards bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_broken_clock` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_chain_of_damavand

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_chain_of_damavand`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: One bronze chain link bright. Curse: Chain weight dragging bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_chain_of_damavand` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_cleanse_before_dawn

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_cleanse_before_dawn`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Dawn cleanse ray over pad. Curse: Lingering violet fog bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_cleanse_before_dawn` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_corrupted_bounty

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_corrupted_bounty`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Gold with purification rim. Curse: Corruption over gold bottom (pairs with golden_bounty theme).

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_corrupted_bounty` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_couplet_immortal

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_couplet_immortal`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Couplet border gold pulse (no readable couplet). Curse: Faded border bottom. --- Total: 43 card IDs (incl. repo + design pool). Next: 04-phase-3-relics-and-strategic.prompt.md

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_couplet_immortal` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_cup_of_vision

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_cup_of_vision`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Jamshid cup glow (abstract). Curse: Cup clouded bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_cup_of_vision` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_dark_route

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_dark_route`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Short path shadow shortcut reward. Curse: Longer path serpent below.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_dark_route` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_derafsh_kaviani

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_derafsh_kaviani`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Royal standard abstract pattern (non-readable). Curse: Torn standard bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_derafsh_kaviani` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_elite_hunt

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_elite_hunt`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Trophy star iron shine. Curse: Elite enemy skull motif bottom (abstract).

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_elite_hunt` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_esfandiyar_armor

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_esfandiyar_armor`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Golden armor gleam. Curse: Armor tarnish, crack line bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_esfandiyar_armor` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_eternal_brazier

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_eternal_brazier`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Ever-burning Sacred Fire brazier, gold dome. Curse: Ash-choked brazier bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_eternal_brazier` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_feathered_rescue

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_feathered_rescue`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Simorgh feather descent light. Curse: Feather scorched bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_feathered_rescue` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_fire_keeper

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_fire_keeper`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Guardian hand cupping flame. Curse: Hand withdrawn, embers die bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_fire_keeper` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_forge_adjacent

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_forge_adjacent`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Two towers linked spark. Curse: One tower isolated dim bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_forge_adjacent` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_forge_memory

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_forge_memory`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Anvil memory spark, star iron glint. Curse: Rust creep on anvil bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_forge_memory` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_forged_oath

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_forged_oath`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Hammer on oath stone spark. Curse: Shattered oath stone bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_forged_oath` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_golden_bounty

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_golden_bounty`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon read: Gold coins / wheat sheaf abstract. Curse read: Corruption veins over treasure bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_golden_bounty` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_gordafarid_resolve

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_gordafarid_resolve`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Shield and banner uplift. Curse: Cracked shield bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_gordafarid_resolve` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_heavy_judgment

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_heavy_judgment`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Ox-head mace impact glyph. Curse: Slow chain on foot bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_heavy_judgment` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_heroic_gate

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_heroic_gate`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Gate reinforced gold. Curse: Gate splinter stress bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_heroic_gate` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_last_stand

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_last_stand`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Lone hero on rock, gold rim. Curse: Encircling shadow army silhouettes bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_last_stand` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_morale_surge

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_morale_surge`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Morale ribbon rising. Curse: Ribbon frayed bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_morale_surge` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_mountain_patience

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_mountain_patience`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Mountain peak stillness, gold rim. Curse: Avalanche shadow bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_mountain_patience` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_narrator_mercy

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_narrator_mercy`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Gentle manuscript light. Curse: Dark ink spill bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_narrator_mercy` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_purifying_chant

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_purifying_chant`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Priestess silhouette, light waves upward. Curse: Muffled dark chant ribbons below.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_purifying_chant` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_qanat_reserve

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_qanat_reserve`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Qanat water channel full. Curse: Channel cracked dry bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_qanat_reserve` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_rakhsh_fury

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_rakhsh_fury`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Rakhsh charge, dust trail. Curse: Reins broken, wild shadow below.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_rakhsh_fury` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_rapid_volley

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_rapid_volley`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Three arrows streak. Curse: Quiver empty bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_rapid_volley` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_sacred_route

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_sacred_route`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Lit path gold. Curse: Path corruption fork bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_sacred_route` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_sacred_scout

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_sacred_scout`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Scout flame beacon. Curse: Beacon smoke blind bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_sacred_scout` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_sacred_wind

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_sacred_wind`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon read: Sacred wind, feather + flame. Curse read: Calm curse band (light cool shadow) or neutral if no curse art. ---

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_sacred_wind` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_serpent_hunger

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_serpent_hunger`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Small SF gain flame. Curse: Serpent consuming tower silhouette bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_serpent_hunger` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_shattered_chrono_dial

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_shattered_chrono_dial`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Time rewind gleam top. Curse: Shattered sun-disk bottom (rewind curse).

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_shattered_chrono_dial` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_sohrab_rage

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_sohrab_rage`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Young warrior fire aura. Curse: Tragic shadow spear motif bottom (subtle).

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_sohrab_rage` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_song_of_the_narrator

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_song_of_the_narrator`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Open manuscript music waves (no text). Curse: Torn page corner bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_song_of_the_narrator` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_stone_of_alborz

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_stone_of_alborz`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Mountain stone radiating light. Curse: Crumbling stone bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_stone_of_alborz` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_wind_of_sistan

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_wind_of_sistan`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Sistan wind spiral, teal ribbon. Curse: Sandstorm choke bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_wind_of_sistan` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_wisdom_of_zal

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_wisdom_of_zal`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Simorgh feather + elder profile abstract. Curse: Feather falling, dim bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_wisdom_of_zal` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — card_zahhak_whisper

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `card_zahhak_whisper`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Boon: Single serpent whisper (small). Curse: Twin serpent hunger eyes bottom.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `card_zahhak_whisper` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_ahriman_shadow_coin

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_ahriman_shadow_coin`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Shadow face coin (curse relic).

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_ahriman_shadow_coin` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_arash_bowstring

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_arash_bowstring`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Bowstring arc silver.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_arash_bowstring` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_armor_of_esfandiyar

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_armor_of_esfandiyar`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Golden vambrace.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_armor_of_esfandiyar` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_arzhang_banner_fragment

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_arzhang_banner_fragment`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Div banner scrap.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_arzhang_banner_fragment` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_bizhan_dagger

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_bizhan_dagger`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Curved dagger bronze.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_bizhan_dagger` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_broken_zervan_ring

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_broken_zervan_ring`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Cracked time ring.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_broken_zervan_ring` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_chains_of_damavand

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_chains_of_damavand`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Three interlocked bronze links.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_chains_of_damavand` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_cup_of_jamshid

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_cup_of_jamshid`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Jewel cup side view.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_cup_of_jamshid` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_damavand_anchor_fragment

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_damavand_anchor_fragment`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Anchor stone chip + chain.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_damavand_anchor_fragment` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_derafsh_kaviani

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_derafsh_kaviani`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Standard fragment, abstract pattern.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_derafsh_kaviani` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_div_blue_eye_stone

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_div_blue_eye_stone`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Div eye in blue stone.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_div_blue_eye_stone` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_dragon_scale

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_dragon_scale`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Azhdaha scale teal-bronze.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_dragon_scale` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_farr_emblem

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_farr_emblem`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Farr glory sun emblem.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_farr_emblem` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_feather_of_simorgh

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_feather_of_simorgh`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Gold-teal feather, strong silhouette.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_feather_of_simorgh` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_fire_of_azar

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_fire_of_azar`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Flame in copper bowl.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_fire_of_azar` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_fire_temple_ash

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_fire_temple_ash`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Sacred ash pinch bowl.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_fire_temple_ash` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_first_talisman

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_first_talisman`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Khan 7 talisman coin.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_first_talisman` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_forge_hammer_fragment

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_forge_hammer_fragment`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Broken hammer head reforging.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_forge_hammer_fragment` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_gate_guardian_plate

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_gate_guardian_plate`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Gate armor plate.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_gate_guardian_plate` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_heroic_banner_pin

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_heroic_banner_pin`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Banner pin brooch.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_heroic_banner_pin` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_hidden_jamshid_shard

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_hidden_jamshid_shard`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Hidden gem facet.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_hidden_jamshid_shard` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_kaveh_apron

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_kaveh_apron`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Smith leather apron + hammer.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_kaveh_apron` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_lion_claw

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_lion_claw`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Khan 1 lion claw bronze.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_lion_claw` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_mountain_echo_stone

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_mountain_echo_stone`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Resonant mountain stone. ---

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_mountain_echo_stone` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_narrator_scroll

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_narrator_scroll`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Rolled scroll seal.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_narrator_scroll` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_olad_guide_map

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_olad_guide_map`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Mountain path map (no labels).

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_olad_guide_map` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_ox_headed_mace

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_ox_headed_mace`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Rostam mace head icon.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_ox_headed_mace` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_purified_root

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_purified_root`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Glowing plant root.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_purified_root` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_qanat_copper_key

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_qanat_copper_key`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Qanat valve key.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_qanat_copper_key` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_qanat_stone

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_qanat_stone`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Carved water channel stone.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_qanat_stone` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_sacred_brazier_core

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_sacred_brazier_core`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Eternal flame core.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_sacred_brazier_core` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_saddle_of_rakhsh

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_saddle_of_rakhsh`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Bronze saddle + stirrup.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_saddle_of_rakhsh` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_seal_of_rudabeh

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_seal_of_rudabeh`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Wax seal disc, floral motif.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_seal_of_rudabeh` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_sistani_wind_knot

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_sistani_wind_knot`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Wind-tied ribbon knot.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_sistani_wind_knot` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_sorceress_broken_cup

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_sorceress_broken_cup`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Shattered feast cup.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_sorceress_broken_cup` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_sorceress_mirror

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_sorceress_mirror`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Cracked hand mirror violet.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_sorceress_mirror` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_star_iron_fragment

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_star_iron_fragment`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Meteorite shard sparkle (forge).

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_star_iron_fragment` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_white_div_stone

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_white_div_stone`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Pale cavern crystal.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_white_div_stone` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_zahhak_chain_seal

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_zahhak_chain_seal`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Serpent-bound medallion.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_zahhak_chain_seal` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — relic_zal_white_feather

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `relic_zal_white_feather`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: White Simorgh down feather.

## Asset-type contract
Create one icon with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 128×128px.
- Grid: 1 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `relic_zal_white_feather` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — strategic_card_consult_narrator

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `strategic_card_consult_narrator`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Manuscript scroll unfurl (no text).

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `strategic_card_consult_narrator` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — strategic_card_exchange_relic

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `strategic_card_exchange_relic`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Two relic silhouettes swap arrows.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `strategic_card_exchange_relic` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — strategic_card_feed_forge

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `strategic_card_feed_forge`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Star iron into anvil flame.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `strategic_card_feed_forge` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — strategic_card_invoke_simorgh

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `strategic_card_invoke_simorgh`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Bird spirit wing descent.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `strategic_card_invoke_simorgh` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — strategic_card_mark_path

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `strategic_card_mark_path`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Chalk path rune on dirt (abstract).

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `strategic_card_mark_path` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — strategic_card_purge_shadow

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `strategic_card_purge_shadow`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Sacred cleanse wave cutting shadow.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `strategic_card_purge_shadow` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — strategic_card_rekindle_region

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `strategic_card_rekindle_region`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Brazier relight on dark pad, gold pulse.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `strategic_card_rekindle_region` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — strategic_card_repair_tower

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `strategic_card_repair_tower`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Masonry hammer + timber spark on tower silhouette.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `strategic_card_repair_tower` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — strategic_card_reposition_tower

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `strategic_card_reposition_tower`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Tower ghost outline arrow slide.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `strategic_card_reposition_tower` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — strategic_card_sacred_reserve

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `strategic_card_sacred_reserve`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: SF flame stored in clay jar. ---

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `strategic_card_sacred_reserve` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — strategic_card_scout_next_wave

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `strategic_card_scout_next_wave`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Eye + horn silhouette over path.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `strategic_card_scout_next_wave` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — strategic_card_strengthen_gate

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `strategic_card_strengthen_gate`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `card_art`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Gate timbers reinforced bronze.

## Asset-type contract
Create one portrait Fate-card or tactical-card visual. Keep decorative motifs only; no readable text. Preserve a clear illustration safe area and, for Fate cards, a visually obvious boon-top / curse-bottom split.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/cards/`. Use stable asset ID `strategic_card_strengthen_gate` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_blood_oath_frame

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `ui_blood_oath_frame`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_asset`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Oath contract plaque; slots: risk icon, reward icon, accepted, completed, failed — no text.

## Asset-type contract
Create a landscape-mobile UI asset or illustration with ornate Persian-manuscript influence, blank plaques, and icon slots only. Do not bake readable text into the art. Keep important UI-safe areas uncluttered.

## Exact technical export contract
- Exact canvas: 4096×2304px.
- Grid: 1 columns × 1 rows. Cell size: 4096×2304px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/`. Use stable asset ID `ui_blood_oath_frame` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_challenge_modifier_icons

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `ui_challenge_modifier_icons`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon_atlas`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Set of 8+ modifier glyphs 128×128 (elite, speed, darkness, etc.).

## Asset-type contract
Create an icon atlas with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 512×256px.
- Grid: 4 columns × 2 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `ui_challenge_modifier_icons` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_community_event

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `ui_community_event`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_asset`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Output: Community ribbon frame (no social logos). --- Next: 05-phase-4-meta-narrative.prompt.md

## Asset-type contract
Create a landscape-mobile UI asset or illustration with ornate Persian-manuscript influence, blank plaques, and icon slots only. Do not bake readable text into the art. Keep important UI-safe areas uncluttered.

## Exact technical export contract
- Exact canvas: 4096×2304px.
- Grid: 1 columns × 1 rows. Cell size: 4096×2304px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/`. Use stable asset ID `ui_community_event` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_daily_tale_banner

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `ui_daily_tale_banner`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_asset`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Output: 2048×512 scroll banner, blank date plaque.

## Asset-type contract
Create a landscape-mobile UI asset or illustration with ornate Persian-manuscript influence, blank plaques, and icon slots only. Do not bake readable text into the art. Keep important UI-safe areas uncluttered.

## Exact technical export contract
- Exact canvas: 2048×512px.
- Grid: 1 columns × 1 rows. Cell size: 2048×512px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/`. Use stable asset ID `ui_daily_tale_banner` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_endless_mode_frame

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `ui_endless_mode_frame`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_asset`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Output: 4096×2304 endless border + wave slot.

## Asset-type contract
Create a landscape-mobile UI asset or illustration with ornate Persian-manuscript influence, blank plaques, and icon slots only. Do not bake readable text into the art. Keep important UI-safe areas uncluttered.

## Exact technical export contract
- Exact canvas: 4096×2304px.
- Grid: 1 columns × 1 rows. Cell size: 4096×2304px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/`. Use stable asset ID `ui_endless_mode_frame` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_fate_card_frames

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `ui_fate_card_frames`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_asset`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Output: 512×768 boon top / curse bottom frame.

## Asset-type contract
Create a landscape-mobile UI asset or illustration with ornate Persian-manuscript influence, blank plaques, and icon slots only. Do not bake readable text into the art. Keep important UI-safe areas uncluttered.

## Exact technical export contract
- Exact canvas: 512×768px.
- Grid: 1 columns × 1 rows. Cell size: 512×768px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/`. Use stable asset ID `ui_fate_card_frames` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_memory_div_frame

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `ui_memory_div_frame`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_asset`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Rival elite portrait frame; adaptation warning; defeat marker.

## Asset-type contract
Create a landscape-mobile UI asset or illustration with ornate Persian-manuscript influence, blank plaques, and icon slots only. Do not bake readable text into the art. Keep important UI-safe areas uncluttered.

## Exact technical export contract
- Exact canvas: 4096×2304px.
- Grid: 1 columns × 1 rows. Cell size: 4096×2304px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/`. Use stable asset ID `ui_memory_div_frame` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_objective_icons

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `ui_objective_icons`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon_atlas`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Output: active, complete, failed — 128×128.

## Asset-type contract
Create an icon atlas with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 384×128px.
- Grid: 3 columns × 1 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `ui_objective_icons` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_pardeh_break

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `ui_pardeh_break`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_asset`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Purpose: Curtain-break before Fate draft. Output: 4096×2304 as a complete no-green full-canvas asset, center card safe zone.

## Asset-type contract
Create a landscape-mobile UI asset or illustration with ornate Persian-manuscript influence, blank plaques, and icon slots only. Do not bake readable text into the art. Keep important UI-safe areas uncluttered.

## Exact technical export contract
- Exact canvas: 4096×2304px.
- Grid: 1 columns × 1 rows. Cell size: 4096×2304px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/`. Use stable asset ID `ui_pardeh_break` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_roguelite_map_background

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `ui_roguelite_map_background`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_asset`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Purpose: Node graph backdrop. Output: 4096×2304 parchment map texture, empty node sockets. ---

## Asset-type contract
Create a landscape-mobile UI asset or illustration with ornate Persian-manuscript influence, blank plaques, and icon slots only. Do not bake readable text into the art. Keep important UI-safe areas uncluttered.

## Exact technical export contract
- Exact canvas: 4096×2304px.
- Grid: 1 columns × 1 rows. Cell size: 4096×2304px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/`. Use stable asset ID `ui_roguelite_map_background` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_roguelite_node_icons

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `ui_roguelite_node_icons`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_icon_atlas`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Output: battle, rest, elite, boss, shop, event — 128×128 each as a complete no-green full-canvas asset.

## Asset-type contract
Create an icon atlas with strong silhouette, clean spacing, and no readable text. Center pivot intent. Use the specified grid exactly.

## Exact technical export contract
- Exact canvas: 384×256px.
- Grid: 3 columns × 2 rows. Cell size: 128×128px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/icons/`. Use stable asset ID `ui_roguelite_node_icons` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_scroll_of_fate

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `ui_scroll_of_fate`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_asset`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Purpose: Fate selection layout. Output: Manuscript scroll, three card slots, no text.

## Asset-type contract
Create a landscape-mobile UI asset or illustration with ornate Persian-manuscript influence, blank plaques, and icon slots only. Do not bake readable text into the art. Keep important UI-safe areas uncluttered.

## Exact technical export contract
- Exact canvas: 4096×2304px.
- Grid: 1 columns × 1 rows. Cell size: 4096×2304px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/`. Use stable asset ID `ui_scroll_of_fate` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.

---

# READY-TO-PASTE IMAGE PROMPT — ui_zahhak_pact_frame

Generate exactly **ONE** game asset for **Shahnameh TD**.

## Asset identity
- Stable asset ID: `ui_zahhak_pact_frame`
- Project phase: Phase 3 — Roguelite UI, Fate Cards, Relics
- Deliverable mode: **FULL-CANVAS NO-GREEN GODOT EXPORT**
- Asset class: `ui_asset`

## Background policy — highest priority
This asset must **not** use a chroma-green background. Do **not** present it as a transparent cut-out. Render the intended artwork across the complete requested canvas and preserve the exact dimensions. Do not crop the map, layer, tile atlas, interface panel, card, icon, portrait, or illustration to only its active shape. For maps and technical map layers, preserve the full tile-aligned rectangle from corner to corner, including inactive tiles, so every export remains coordinate-locked for Godot. For tilesets and icon atlases, fully populate the intended cells and preserve tile boundaries without printing visible guide lines into the final image. For UI, card, portrait, and illustration assets, use a deliberate complete composition or suitable designed background/frame. Do not add chroma green merely to fill unused space.

## Global Shahnameh TD visual system
Hand-painted 2D game art for **Shahnameh TD**, a landscape-mobile active tower-defense roguelite inspired by Ferdowsi's Shahnameh, Persian miniature painting, and Zoroastrian Sacred Fire versus corruption.

Use the approved `hero_rostam` design as the style-system anchor for line weight, palette, painterly cel-shading, and gameplay readability. Do not copy Rostam's costume onto unrelated characters.

Art direction: strong dark-brown or near-black contours, controlled internal lines, readable silhouettes, painterly cel-shading, Iranian-epic materials: bronze, gold, copper, leather, timber, stone, textile, parchment. Palette: deep teal, lapis blue, crimson, rust red, ivory, charcoal. Sacred Fire uses warm orange, gold, copper, and ivory highlights. Corruption uses restrained cold blue, muted shadow-violet, and charcoal; never neon sci-fi purple. Use an elevated three-quarter gameplay perspective unless the asset is explicitly UI, portrait, icon, tile, or illustration. Keep silhouettes readable at landscape-mobile zoom.

## Asset-specific direction
Read: Pact serpent frame; corruption-risk, sacrifice, reward icons.

## Asset-type contract
Create a landscape-mobile UI asset or illustration with ornate Persian-manuscript influence, blank plaques, and icon slots only. Do not bake readable text into the art. Keep important UI-safe areas uncluttered.

## Exact technical export contract
- Exact canvas: 4096×2304px.
- Grid: 1 columns × 1 rows. Cell size: 4096×2304px.
- Pivot intent for Godot: center.
- FULL-CANVAS EXPORT: do not use chroma green and do not use a transparent cut-out presentation. Fill the complete requested canvas with the intended artwork or a layer-appropriate full-canvas base. Preserve exact dimensions and coordinates. Do not crop to active shapes. Do not draw visible grid guide lines in the final export.
- Godot target folder: `art/ui/`. Use stable asset ID `ui_zahhak_pact_frame` as the export basename.

## Required result
Return only the final image asset. Do not include explanation, labels, filenames, watermarks, or a contact-sheet title inside the image.

## Negative prompt
Avoid: photorealistic render, 3D CGI, Unreal or Unity screenshot look, generic Western high fantasy, European plate armor, Viking armor, Roman armor, samurai armor, cyberpunk, neon, flat corporate vector, chibi anime, manga speed lines, stock-photo look, watermark, signature, logo unless requested, readable text, fake Persian or Arabic calligraphy, fake runes, excessive spikes, excessive bloom, lens flare, heavy motion-blur smear, cropped head, cropped hands, cropped feet, broken anatomy, inconsistent lighting, muddy gray corruption, green-screen spill, green fringe, green outline, green cast shadow, cluttered scenery behind isolated sprites, duplicate limbs, merged frames, frame overlap, unequal sprite cells, inconsistent character scale, inconsistent costume between animation frames.
